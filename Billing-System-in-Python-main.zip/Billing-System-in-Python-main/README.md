# Billing-System-in-Python
Billing System project is a web application which is developed in Python platform.
![bill](https://user-images.githubusercontent.com/78893155/155141055-f91bd409-4027-493f-9be6-665966e330b7.jpg)


